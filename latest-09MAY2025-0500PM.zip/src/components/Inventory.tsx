function Inventory() {
    return <>
        <h2>Inventory</h2>
        <p>Inventory content goes here..</p>
    </>
}

export default Inventory;
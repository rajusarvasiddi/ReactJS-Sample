import React from "react";

const User: React.FC = () => {
    return <>
        <h1>User(s)</h1>
    </>
}

export default User;
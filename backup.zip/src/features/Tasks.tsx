function Tasks() {
    return <>
        <h2>Tasks</h2>
        <p>List of tasks goes here..</p>
    </>
}

export default Tasks;
import { Outlet } from "react-router-dom";

function Calendar() {
    return <div>CALENDAR Content goes here.. 
        <Outlet /></div>
}

export default Calendar;